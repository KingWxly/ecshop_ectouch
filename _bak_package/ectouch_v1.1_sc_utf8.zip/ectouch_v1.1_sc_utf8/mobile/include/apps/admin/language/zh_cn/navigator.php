<?php

/**
 * ECTouch Open Source Project
 * ============================================================================
 * Copyright (c) 2012-2014 http://ectouch.cn All rights reserved.
 * ----------------------------------------------------------------------------
 * 文件名称：favourable.php
 * ----------------------------------------------------------------------------
 * 功能描述：导航语言
 * ----------------------------------------------------------------------------
 * Licensed ( http://www.ectouch.cn/docs/license.txt )
 * ----------------------------------------------------------------------------
 */
$_LANG['add_new'] = '添加导航';
$_LANG['system_main'] = '系统内容';
$_LANG['item_name'] = '名称';
$_LANG['item_ifshow'] = '是否显示';
$_LANG['item_opennew'] = '是否新窗口';
$_LANG['item_type'] = '位置';
$_LANG['edit'] = '编辑';
$_LANG['item_pic'] = '图片地址';
$_LANG['item_url'] = '链接地址';
$_LANG['item_vieworder'] = '排序';
$_LANG['top'] = '顶部';
$_LANG['middle'] = '中间';
$_LANG['bottom'] = '底部 ';
$_LANG['edit_ok'] = '操作成功';
$_LANG['go_list'] = '返回列表';
$_LANG['ckdel'] = '确定删除?';

$_LANG['namecannotnull'] = '请输入导航栏名称！';
$_LANG['linkcannotnull'] = '请输入链接地址！';

$_LANG['notice_url'] = '如果是本站的网址，可缩写为与商城根目录相对地址<br>其他情况都应该输入完整的网址';
?>