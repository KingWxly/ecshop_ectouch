<script type="text/javascript">
function showImg(id, title){
	var _content = $('#'+id).html();
	art.dialog({
		id: 'showImg',
		padding: 0,
		title: title,
		content: _content,
		lock: false
	});
}
$(function(){
	//弹出框
	$(".fancybox").fancybox({
		width		: '60%',
		height		: '60%',
		closeBtn	: false,
		title       : ''
	});
})
</script>
</body>
</html>