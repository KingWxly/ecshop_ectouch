var menu = '<li class="explode" name="menu" key="99_wechat" id="99_wechat">微信管理' +
  '<ul>' +
    '<li class="menu-item"><a href="../mobile/index.php?m=admin&c=wechat&a=modify" target="main-frame">微信设置</a></li>' +
    '<li class="menu-item"><a href="../mobile/index.php?m=admin&c=wechat&a=modify" target="main-frame">群发消息</a></li>' +
    '<li class="menu-item"><a href="../mobile/index.php?m=admin&c=wechat&a=modify" target="main-frame">自动回复</a></li>' +
    '<li class="menu-item"><a href="../mobile/index.php?m=admin&c=wechat&a=modify" target="main-frame">微信菜单</a></li>' +
    '<li class="menu-item"><a href="../mobile/index.php?m=admin&c=wechat&a=modify" target="main-frame">粉丝管理</a></li>' +
    '<li class="menu-item"><a href="../mobile/index.php?m=admin&c=wechat&a=modify" target="main-frame">素材管理</a></li>' +
    '<li class="menu-item"><a href="../mobile/index.php?m=admin&c=wechat&a=modify" target="main-frame">功能扩展</a></li>' +
    '<li class="menu-item"><a href="../mobile/index.php?m=admin&c=wechat&a=modify" target="main-frame">提醒设置</a></li>' +
    '<li class="menu-item"><a href="../mobile/index.php?m=admin&c=wechat&a=modify" target="main-frame">多客服设置</a></li>' +
    '<li class="menu-item"><a href="../mobile/index.php?m=admin&c=wechat&a=modify" target="main-frame">扫码分成</a></li>' +
    '<li class="menu-item"><a href="../mobile/index.php?m=admin&c=wechat&a=modify" target="main-frame">渠道二维码</a></li>' +
  '</ul>' +
'</li>';
document.write(menu);