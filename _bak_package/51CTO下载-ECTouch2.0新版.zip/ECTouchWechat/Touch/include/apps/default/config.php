<?php

return array(
    'APP_STATE' => 1,
    'APP_NAME' => 'ECTOUCH',
    'APP_VER' => '1.0.2014.0520',
    'APP_AUTHOR' => 'ectouch team',
    'APP_ORIGINAL_PREFIX' => '',
    'APP_TABLES' => '',
);
