{include file="wechat_header"}
<div class="panel panel-default" style="margin:0;">
    <div class="panel-heading">编辑</div>
	<form action="{url('media_edit')}" method="post" class="form-horizontal" role="form" onSubmit="return false;">
      <table id="general-table" class="table table-hover ectouch-table">
       <tr>
          <td width="200">名称:</td>
          <td><div class="col-md-4">
              <input type='text' name='file_name' value="{$pic['file_name']}" class="form-control input-sm" />
            </div></td>
        </tr>
        <tr>
          <td width="200"></td>
          <td><div class="col-md-4">
              	<input type="hidden" name="id" value="{$pic['id']}" />
				<input type="submit" value="{$lang['button_submit']}" class="btn btn-primary closebox" />
              	<input type="reset" value="{$lang['button_reset']}" class="btn btn-default closebox" />
            </div></td>
        </tr>
        </table>
	</form>
</div>
<script type="text/javascript">
$(function(){
	$(".form-horizontal").submit(function(){
		var ajax_data = $(".form-horizontal").serialize();
		$.post("{url('media_edit')}", ajax_data, function(data){
		    if(data.status > 0){
		    	window.parent.location.reload();
			}
		    else{
			    alert(data.error);
			    return false;
			}
		}, 'json');
	});
})
</script>
{include file="pagefooter"}