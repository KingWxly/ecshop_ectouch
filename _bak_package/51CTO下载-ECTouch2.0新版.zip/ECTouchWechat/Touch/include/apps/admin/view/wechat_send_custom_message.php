{include file="wechat_header"}
<div class="panel panel-default" style="margin:0;">
    <div class="panel-heading">发送客服消息</div>
    <div class="panel-body">
    	<form action="{url('send_custom_message')}" method="post" class="form-horizontal" role="form" onSubmit="return false;">
          <table id="general-table" class="table table-hover ectouch-table">
            <tr>
              <td width="200">{$lang['message_content']}:</td>
              <td><div class="col-md-7">
                  <textarea name="data[msg]" class="form-control" row="3"></textarea>
                  <span class="help-block">{$lang['sub_help1']}</span>
                  </div></td>
            </tr>
            <tr>
              <td width="200">{$lang['sub_nickname']}:</td>
              <td><div class="col-md-6">{$info['nickname']}</div></td>
            </tr>
            <tr>
              <td width="200">{$lang['sub_openid']}:</td>
              <td><div class="col-md-6">{$info['openid']}</div></td>
            </tr>
            <tr>
              <td width="200"></td>
              <td><div class="col-md-4">
                    <input type="hidden" name="data[uid]" value="{$info['uid']}" />
                    <input type="hidden" name="openid" value="{$info['openid']}" />
    				<input type="submit" value="{$lang['button_send']}" class="btn btn-primary" />
                  	<input type="reset" value="{$lang['button_reset']}" class="btn btn-default" />
                </div></td>
            </tr>
            </table>
    	</form>
    </div>
</div>
<script type="text/javascript">
$(function(){
	$(".form-horizontal").submit(function(){
		var ajax_data = $(".form-horizontal").serialize();
		$.post("{url('send_custom_message')}", ajax_data, function(data){
		    if(data.status > 0){
		    	window.parent.location.reload();
			}
		    else{
			    alert(data.error);
			    return false;
			}
		}, 'json');
	});
})
</script>