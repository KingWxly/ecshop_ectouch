{include file="wechat_header"}
<div class="panel panel-default" style="margin:0;">
    <div class="panel-heading">{$lang['qrcode']}</div>
    <div class="panel-body text-center">
    	<img src="{$qrcode_url}" alt="{$lang['qrcode']}" />
    </div>
</div>
{include file="pagefooter"}