{include file="pageheader"}

<table id="list-table" class="table table-bordered table-striped table-hover">
  <tr class="active">
    <th class="text-center" width="20%">{$lang['act_name']}</th>
    <th class="text-center" width="20%">{$lang['start_time']}</th>
    <th class="text-center">{$lang['end_time']}</th>
    <th class="text-center" width="10%">{$lang['max_amount']}</th>
    <th class="text-center" width="10%">{$lang['min_amount']}</th>
    <th class="text-center" width="10%">{$lang['handler']}</th>
  </tr>
  {loop $list $key $vo}
  <tr>
    <td class="text-center"><a href="{url('edit', array('id'=>$vo['act_id']))}">{$vo['act_name']}</a></td>
    <td class="text-center">{$vo['start_time']}</td>
    <td class="text-left">{$vo['end_time']}</td>
    <td class="text-center">{$vo['max_amount']}</td>
    <td class="text-center">{$vo['min_amount']}</td>
    <td class="text-center"><a href="{url('edit', array('id'=>$vo['act_id']))}">{$lang['edit']}</a> | <a href="{url('del', array('id'=>$vo['brand_id']))}">{$lang['remove']}</a></td>
  </tr>
  {/loop}
</table>

{include file="pageview"}

{include file="pagefooter"}