{include file="pageheader"}
<style>
.article{border:1px solid #ddd;padding:5px 5px 0 5px;}
.cover{height:160px; position:relative;margin-bottom:5px;overflow:hidden;}
.article .cover img{width:100%; height:auto;}
.article span{height:40px; line-height:40px; display:block; z-index:5; position:absolute;width:100%;bottom:0px; color:#FFF; padding:0 10px; background-color:rgba(0,0,0,0.6)}
.article_list{padding:5px;border:1px solid #ddd;border-top:0;overflow:hidden;}
</style>
<div class="container-fluid" style="padding:0">
  <div class="row" style="margin:0">
    <div class="col-md-2 col-sm-2 col-lg-1" style="padding-right:0;">{include file="wechat_left_menu"}</div>
    <div class="col-md-10 col-sm-10 col-lg-11" style="padding-right:0;">
      <div class="panel panel-default">
        <div class="panel-heading">多图文编辑</div>
      	<form action="{url('article_edit_news')}" method="post" enctype="multipart/form-data" class="form-horizontal" role="form">
            <table id="general-table" class="table table-hover ectouch-table">  
              <tr>
                <td width="200">选择图文信息：</td>
                <td><div class="col-md-4">
                    <a class="btn btn-primary fancybox fancybox.iframe" href="{url('articles_list')}">选择图文信息</a>
                    <a class="btn btn-default" href="javascript:if(confirm('{$lang['confirm_delete']}')){window.location.href='{url('article_news_del', array('id'=>$id))}'};">清空重选</a>
                    <span class="help-block">一个图文消息支持1到10条图文，多于10条会发送失败</span>
                  </div></td>
              </tr>
              <tr class="content">
                <td width="200">图文信息：</td>
                <td><div class="col-md-3 ajax-data">
                    {if $articles}
                    {loop $articles $k $v}
                        {if $k == 0}
                        <div class="article">
                            <input type="hidden" name="article[]" value="{$v['id']}" />
                            <p>{date('Y年m月d日', $v['add_time'])}</p>
                            <div class="cover"><img src="{$v['file']}" /><span>{$v['title']}</span></div>
                        </div>
                        {else}
                        <div class="article_list">
                            <input type="hidden" name="article[]" value="{$v['id']}" />
                            <span>{$v['title']}</span>
                            <img src="{$v['file']}" width="78" height="78" class="pull-right" />
                        </div>
                        {/if}
                    {/loop}
                    {/if}
                  </div></td>
              </tr>
              <tr>
                <td width="200">排序：</td>
                <td>
                    <div class="col-md-1">
                        <input type="text" name="sort" class="form-control input-sm" value="{$sort}" />
                    </div>
                </td>
              </tr>
              <tr>
                <td width="200"></td>
                <td><div class="col-md-4">
                    <input type="hidden" name="id" value="{$id}" />
      				<input type="submit" value="{$lang['button_submit']}" class="btn btn-primary" />
                    <input type="reset" value="{$lang['button_reset']}" class="btn btn-default" />
                  </div></td>
              </tr>
              </table>
      	</form>
      </div>
    </div>
  </div>
</div>
{include file="pagefooter"}