{include file="header"}
<div class="title">微信通设置</div>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
	<form method="post" action="{url('wechat/setting')}">
	{loop $setting $key $vo}
	<tr>
		<td{if $key==0} width="160"{/if}>{$vo['name']}</td>
		<td>{$vo['html']}</td>
	</tr>
	{/loop}
	<tr>
		<td></td>
		<td><input type="submit" name="submit" value="提 交" /></td>
	</tr>
	</form>
</table>

</body>
</html>