{include file="wechat_header"}
<div class="panel panel-default" style="margin:0;">
<div class="panel-heading">{$lang['add'].$lang['qrcode']}</div>
<div class="panel-body">
	<form action="{url('qrcode_edit')}" method="post" class="form-horizontal" role="form" onSubmit="return false;">
      <table id="general-table" class="table table-hover ectouch-table">
       <tr>
          <td width="200">{$lang['qrcode_type']}:</td>
          <td><div class="col-md-4">
              <select class="form-control input-sm" name="data[type]">
              	<option value="0">{$lang['qrcode_short']}</option>
              	<option value="1">{$lang['qrcode_forever']}</option>
              </select>
            </div></td>
        </tr>
        <tr>
          <td width="200">{$lang['qrcode_valid_time']}:</td>
          <td><div class="col-md-6">
              <input type="text" name="data[expire_seconds]" class="form-control input-sm" />
               <span class="help-block">{$lang['qrcode_help1']}</span>
            </div></td>
        </tr>
        <tr>
          <td width="200">{$lang['qrcode_function']}:</td>
          <td><div class="col-md-6">
              <input type="text" name="data[function]" class="form-control input-sm" />
            </div></td>
        </tr>
        <tr>
          <td width="200">{$lang['qrcode_scene_value']}:</td>
          <td><div class="col-md-6">
              <input type="text" name="data[scene_id]" class="form-control input-sm" />
              <span class="help-block">{$lang['qrcode_help2']}</span>
            </div></td>
        </tr>
        <tr>
          <td width="200">{$lang['wechat_status']}:</td>
          <td><div class="col-md-10">
          		<div class="btn-group" data-toggle="buttons">
	              	<label class="btn btn-primary active">
        					  <input type="radio" name="data[status]" value="1" checked />{$lang['enabled']}
        					</label>
        					<label class="btn btn-primary">
        					  <input type="radio" name="data[status]" value="0" />{$lang['disabled']}
        					</label>
				</div>
            </div></td>
        </tr>
        <tr>
          <td width="200">{$lang['sort_order']}:</td>
          <td><div class="col-md-2">
              <input type="text" name="data[sort]" class="form-control input-sm" />
            </div></td>
        </tr>
        <tr>
          <td width="200"></td>
          <td><div class="col-md-4">
				<input type="submit" value="{$lang['button_submit']}" class="btn btn-primary" />
              	<input type="reset" value="{$lang['button_reset']}" class="btn btn-default" />
            </div></td>
        </tr>
        </table>
	</form>
</div>
</div>
<script type="text/javascript">
$(function(){
	$(".form-horizontal").submit(function(){
	    var ajax_data = $(this).serialize();
	    $.post("{url('qrcode_edit')}", ajax_data, function(data){
	        if(data.status > 0){
	            window.parent.location.reload();
			}
	        else{
	            alert(data.msg);
	            return false;
		    }
	    }, 'json');
	});
})
</script>
{include file="pagefooter"}