{include file="pageheader"}
<div class="container-fluid" style="padding:0">
	<div class="row" style="margin:0">
	  <div class="col-md-2 col-sm-2 col-lg-1" style="padding-right:0;">{include file="wechat_left_menu"}</div>
	  <div class="col-md-10 col-sm-10 col-lg-11" style="padding-right:0;">
		<div class="panel panel-default">
			<div class="panel-heading">积分规则</div>
            <form action="{url('point')}" method="post" class="form-horizontal" role="form">
			<table class="table table-hover ectouch-table">
    			<tr>
                    <th class="text-center">规则名称</th>
                    <th class="text-center">状态</th>
                    <th class="text-center">积分值</th>
                    <th class="text-center">有效次数</th> 
    			</tr>
			{loop $list $key $val}
                <tr>
                    <td class="text-center">{$val['name']}</td>
                    <td class="text-center">
                        <div class="btn-group" data-toggle="buttons">
                        <input type="hidden" name="id[{$key}]" value="{$val['id']}" />
                            <label class="btn btn-primary {if $val['config']['enable']}active{/if}">
                                <input type="radio" name="enable[{$key}]" {if $val['config']['enable']}checked{/if} value="1">开启
                            </label>
                            <label class="btn btn-primary {if empty($val['config']['enable'])}active{/if}">
                                <input type="radio" name="enable[{$key}]" {if empty($val['config']['enable'])}checked{/if} value="0">关闭
                            </label>
                        </div>
                    </td>
                    <td class="text-center"><input type="text" name="point_value[{$key}]" class="form-control" value="{$val['config']['point_value']}"></td>
                    <td class="text-center"><input type="text" name="point_num[{$key}]" class="form-control" value="{$val['config']['point_num']}"></td>
                </tr>
            {/loop}
            <tr>
                <td colspan="4" class="text-center">
                    <input type="submit" name="submit" value="确认" class="btn btn-primary" />
                    <input type="reset" name="reset" value="重置" class="btn btn-default" />
                </td>
            </tr>
			</table>
			</form>
		</div>
	  </div>
	</div>
</div>
{include file="pagefooter"}