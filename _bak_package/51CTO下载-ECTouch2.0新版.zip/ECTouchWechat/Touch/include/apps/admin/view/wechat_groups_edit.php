{include file="wechat_header"}
<div class="panel panel-default" style="margin:0;">
    <div class="panel-heading">{$lang['group_edit']}</div>
	<form action="{url('groups_edit')}" method="post" class="form-horizontal" role="form" onSubmit="return false;">
      <table id="general-table" class="table table-hover ectouch-table">
       <tr>
          <td width="200">{$lang['group_name']}:</td>
          <td><div class="col-md-4">
              <input type='text' name='name' maxlength="20" value="{$group['name']}" class="form-control input-sm" />
            </div></td>
        </tr>
        <tr>
          <td width="200"></td>
          <td><div class="col-md-4">
              	<input type="hidden" name="id" value="{$group['id']}" />
              	<input type="hidden" name="group_id" value="{$group['group_id']}" />
				<input type="submit" value="{$lang['button_submit']}" class="btn btn-primary" />
              	<input type="reset" value="{$lang['button_reset']}" class="btn btn-default" />
            </div></td>
        </tr>
        </table>
	</form>
</div>
<script type="text/javascript">
$(function(){
	$(".form-horizontal").submit(function(){
		var ajax_data = $(".form-horizontal").serialize();
		$.post("{url('groups_edit')}", ajax_data, function(data){
		    if(data.status > 0){
		    	window.parent.location.reload();
			}
		    else{
			    alert(data.msg);
			    return false;
			}
		}, 'json');
	});
})
</script>
{include file="pagefooter"}