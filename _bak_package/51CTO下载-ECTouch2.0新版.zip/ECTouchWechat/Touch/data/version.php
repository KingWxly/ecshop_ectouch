<?php
define('APPNAME', 'ECTOUCH');
define('VERSION', '1.0Beta2');
define('RELEASE', '20141019');
define('ECTOUCH_AUTH_KEY', '');