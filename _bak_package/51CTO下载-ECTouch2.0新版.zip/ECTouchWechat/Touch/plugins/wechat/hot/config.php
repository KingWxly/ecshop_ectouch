<?php
return array(
    'name' => '热卖商品',
    'command' => 'hot',// 关键词
    'keywords' => 'hot', // 扩展词
    'author' =>'ECTOUCH TEAM',// 作者
    'website' => 'http://www.ectouch.cn',// 网址
);