<?php
return array(
    'name' => '订单查询',
    'command' => 'ddcx',// 关键词
    'keywords' => 'ddcx,订单查询', // 扩展词
    'author' =>'ECTOUCH TEAM',// 作者
    'website' => 'http://www.ectouch.cn',// 网址
);