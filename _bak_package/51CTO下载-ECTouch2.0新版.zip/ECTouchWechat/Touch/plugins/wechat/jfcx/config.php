<?php
return array(
    'name' => '积分查询',
    'command' => 'jfcx',// 关键词
    'keywords' => 'jfcx,积分查询', // 扩展词
    'author' =>'ECTOUCH TEAM',// 作者
    'website' => 'http://www.ectouch.cn',// 网址
);