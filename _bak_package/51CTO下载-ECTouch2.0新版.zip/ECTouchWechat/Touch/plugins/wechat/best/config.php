<?php
return array(
    'name' => '精品',
    'command' => 'best',// 关键词
    'keywords' => 'best', // 扩展词
    'author' =>'ECTOUCH TEAM',// 作者
    'website' => 'http://www.ectouch.cn',// 网址
);