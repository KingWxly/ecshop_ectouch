<?php
return array(
    'name' => '新品',
    'command' => 'news',// 关键词
    'keywords' => 'news', // 扩展词
    'author' =>'ECTOUCH TEAM',// 作者
    'website' => 'http://www.ectouch.cn',// 网址
);