<?php
return array(
    'name' => '砸金蛋',
    'command' => 'zjd',// 关键词
    'keywords' => '砸金蛋,zjd', // 扩展词
    'author' =>'ECTOUCH TEAM',// 作者
    'website' => 'http://www.ectouch.cn',// 网址
);