<?php
return array(
    'name' => '会员绑定',
    'command' => 'bd',// 关键词
    'keywords' => '绑定', // 扩展词
    'author' =>'ECTOUCH TEAM',// 作者
    'website' => 'http://www.ectouch.cn',// 网址
);