<?php
return array(
    'name' => '签到送积分',
    'command' => 'sign',// 关键词
    'keywords' => 'sign,签到', // 扩展词
    'author' =>'ECTOUCH TEAM',// 作者
    'website' => 'http://www.ectouch.cn',// 网址
);